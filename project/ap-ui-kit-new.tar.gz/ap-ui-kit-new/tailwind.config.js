const plugin = require('tailwindcss/plugin');

//ToDo: Remove fontSizes, lineHeights, spacing. they are duplicated
const fontSizes = [24, 20, 18, 16, 14, 12, 11, 10];
const lineHeights = [32, 28, 24, 22, 20, 18];
const spacing = [0, 4, 8, 12, 16, 20, 24, 32, 40, 44, 48, 56, 64, 80, 128];
const borderRadius = [4, 8, 12, 16, 20, 24, 32];
const colors = {
  red_dark: '#EB6750',
  green_dark: '#37B399',
  red2: '#B01116',
  red_error_dark: '#FF6666',
  yellow_warning_dark: '#FFD350',
  green_success_dark: '#68C17C',
  blue_info_dark: '#61AAFF',
  brown_more_dark: '#DCC48E',
  green_dark_50: '#8037B399',
  white: { 100: '#FFFFFF' },
  gray: {
    50: '#F7F7F7',
    100: '#E1E1E1',
    200: '#C8C8C8',
    300: '#ACACAC',
    400: '#919191',
    500: '#6E6E6E',
    600: '#4A4A4A',
    700: '#303030',
    800: '#1A1A1A',
    900: '#121212',
  },
  black: {
    3: '#08000000',
    5: '#0d000000',
    10: '#1a000000',
    15: '#26000000',
    35: '#59000000',
    50: '#80000000',
    100: '#000000',
  },
  dp: {
    '2dp': '#1e1e1e',
    '6dp': '#2c2c2c',
    '12dp': '#333333',
    '24dp': '#3838383',
    '32dp': '#444444',
  },
  payment: {
    100: '#FFCDC3',
    200: '#FF9987',
    300: '#F96C53',
    400: '#E64225',
    500: '#B01116',
    600: '#711618',
  },
  health: {
    100: '#B2FFDB',
    200: '#83FFC4',
    300: '#66DFA6',
    400: '#3FB97F',
    500: '#16995B',
    600: '#026436',
  },
};

const convertArrayToObject = array => {
  const initialValue = {};
  return array.reduce((obj, item) => {
    return {
      ...obj,
      [item]: `${item / 16}rem`,
    };
  }, initialValue);
};

const convertArrayToPattern = (array, key) => {
  return new RegExp(`${key}-(${array.join('|')})`);
};

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    fontSize: convertArrayToObject(fontSizes),
    lineHeight: convertArrayToObject(lineHeights),
    spacing: convertArrayToObject(spacing),
    borderRadius: convertArrayToObject(borderRadius),
    colors,
    extend: {},
  },
  safelist: [
    { pattern: convertArrayToPattern(fontSizes, 'text') },
    { pattern: /leading-/ },
    { pattern: /rounded-/ },
  ],
  plugins: [
    plugin(({ addBase, theme }) => {
      const classes = {};
      const darkClasses = {};
      const typography = [
        { name: 't1', color: theme('colors.gray.800') },
        { name: 't2', color: theme('colors.gray.700') },
        { name: 't3', color: theme('colors.gray.600') },
        { name: 't4', color: theme('colors.gray.500') },
        { name: 't5', color: theme('colors.gray.400') },
        { name: 't6', color: theme('colors.gray.400') },
        { name: 't7-1', color: theme('colors.gray.300') },
        { name: 't7-2', color: theme('colors.gray.100') },
        { name: 't8', color: theme('colors.gray.100') },
        { name: 't9', color: theme('colors.white.100') },
      ];

      const typographyDark = [
        { name: 't1', color: theme('colors.white.100') },
        { name: 't2', color: theme('colors.gray.50') },
        { name: 't3', color: theme('colors.gray.100') },
        { name: 't4', color: theme('colors.gray.200') },
        { name: 't5', color: theme('colors.gray.300') },
        { name: 't6', color: theme('colors.gray.400') },
        { name: 't7_1', color: theme('colors.gray.500') },
        { name: 't7_2', color: theme('colors.gray.500') },
        { name: 't8', color: theme('colors.gray.600') },
        { name: 't9', color: theme('colors.gray.800') },
      ];

      const card = [
        { name: 'backgroundColor', color: theme('colors.gray.50') },
        { name: '2dp', color: theme('colors.gray.50') },
        { name: '6dp', color: theme('colors.white.100') },
        { name: '12dp', color: theme('colors.white.100') },
        { name: '24dp', color: theme('colors.white.100') },
        { name: '32dp', color: theme('colors.white.100') },
      ];

      const cardDark = [
        { name: 'backgroundColor', color: theme('colors.gray.900') },
        { name: '2dp', color: theme('colors.dp.2dp') },
        { name: '6dp', color: theme('colors.dp.6dp') },
        { name: '12dp', color: theme('colors.dp.12dp') },
        { name: '24dp', color: theme('colors.dp.24dp') },
        { name: '32dp', color: theme('colors.dp.32dp') },
      ];

      const gradient = [
        {
          name: 'buttonsGradient',
          color:
            'linear-gradient(0deg, #FFFFFF 57.95%, rgba(255, 255, 255, 0.7) 82%, rgba(255, 255, 255, 0) 100%)',
        },
      ];

      const gradientDark = [
        {
          name: 'buttonsGradient',
          color:
            'linear-gradient(0deg, #2C2C2C 57.95%, rgba(44, 44, 44, 0.7) 82%, rgba(44, 44, 44, 0) 100%)',
        },
      ];

      for (let i = 0; i < typography.length; i++) {
        const el = typography[i];
        classes[`.text-${el.name}`] = { color: el.color };
      }

      for (let i = 0; i < typographyDark.length; i++) {
        const el = typographyDark[i];
        darkClasses[`.text-${el.name}`] = { color: el.color };
      }

      for (let i = 0; i < card.length; i++) {
        const el = card[i];
        classes[`.bg-${el.name}`] = { background: el.color };
      }

      for (let i = 0; i < cardDark.length; i++) {
        const el = cardDark[i];
        darkClasses[`.bg-${el.name}`] = { background: el.color };
      }

      for (let i = 0; i < gradient.length; i++) {
        const el = gradient[i];
        classes[`.bg-${el.name}`] = { background: el.color };
      }

      for (let i = 0; i < gradientDark.length; i++) {
        const el = gradientDark[i];
        darkClasses[`.bg-${el.name}`] = { background: el.color };
      }

      addBase({
        '.light-theme': classes,
        '.dark-theme': darkClasses,
      });
    }),
  ],
  mode: 'jit',
  purge: ['./src/**/*.{js,jsx,ts,tsx}', './stories/*'],
};
