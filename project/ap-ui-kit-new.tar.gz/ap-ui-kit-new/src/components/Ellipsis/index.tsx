import React, { FC } from 'react';
import styles from './ellipsis.module.scss';

export const Ellipsis: FC = () => {
  return (
    <div className={styles['lds-ellipsis']}>
      <div>
        <div />
      </div>
      <div>
        <div />
      </div>
      <div>
        <div />
      </div>
      <div>
        <div />
      </div>
      <div>
        <div />
      </div>
    </div>
  );
};
