import React, { FC, HTMLAttributes } from 'react';
import { Button, ButtonProps } from '../Button';

interface Props extends HTMLAttributes<HTMLDivElement> {
  primaryButton: ButtonProps;
  secondaryButton?: ButtonProps;
}

export const StickyButtons: FC<Props> = ({ primaryButton, secondaryButton }) => {
  return (
    <div className="flex gap-12 p-16 bg-buttonsGradient fixed bottom-0 right-0 left-0">
      <Button {...primaryButton} />
      {secondaryButton && <Button {...secondaryButton} isReverse />}
    </div>
  );
};
