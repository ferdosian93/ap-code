import React, { FC, HTMLAttributes, ReactNode } from 'react';
import classNames from 'classnames';
import styles from './styles.module.scss';

interface Props extends HTMLAttributes<HTMLDivElement> {
  children?: ReactNode;
  type?: string;
  extraClasses?: string;
}

export const ThemeProvider: FC<Props> = ({ children, type, extraClasses }) => {
  const selectedType =
    type && styles[type.toLocaleLowerCase()]
      ? type.toLocaleLowerCase()
      : 'dark';

  return (
    //ToDo: remove public css colors. actually remove dark and light classes and scss files
    <div
      className={classNames(
        styles[selectedType],
        `${selectedType}-theme`,
        extraClasses
      )}
    >
      {children}
    </div>
  );
};
