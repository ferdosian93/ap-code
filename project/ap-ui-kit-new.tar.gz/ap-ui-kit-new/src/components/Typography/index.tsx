//ToDo: recheck structure
import { FC, HTMLAttributes, ReactNode, createElement } from 'react';

const fontSizes = [24, 20, 18, 16, 14, 12, 11, 10];
const lineHeights = [32, 28, 24, 22, 20, 18];
const typographies = [
  { name: 'h1', size: 24, lineHeight: 32, solid: false },
  { name: 'h2', size: 20, lineHeight: 28, solid: false },
  { name: 'h3', size: 18, lineHeight: 24, solid: false },
  { name: 'h4', size: 16, lineHeight: 24, solid: false },
  { name: 'h5', size: 14, lineHeight: 24, solid: false },
  { name: 'h6', size: 12, lineHeight: 24, solid: false },
  { name: 'p', size: 14, lineHeight: 24, solid: false },
  { name: 'span', size: 14, lineHeight: 24, solid: false },
  { name: 'title1', size: 20, lineHeight: 24, solid: true },
  { name: 'title2', size: 18, lineHeight: 24, solid: true },
  { name: 'title3', size: 16, lineHeight: 22, solid: true },
  { name: 'title4', size: 14, lineHeight: 20, solid: true },
  { name: 'title5', size: 12, lineHeight: 18, solid: true },
  { name: 'body1', size: 18, lineHeight: 24, solid: true },
  { name: 'body2', size: 16, lineHeight: 24, solid: true },
  { name: 'body3', size: 14, lineHeight: 20, solid: true },
  { name: 'body4', size: 12, lineHeight: 20, solid: true },
  { name: 'body5', size: 11, lineHeight: 20, solid: true },
  { name: 'body6', size: 10, lineHeight: 18, solid: true },
  { name: 'overline1', size: 16, lineHeight: 24, solid: true },
  { name: 'overline2', size: 14, lineHeight: 22, solid: true },
  { name: 'overline3', size: 12, lineHeight: 20, solid: true },
];

type TypographytypeVariants = typeof typographies[number]['name'];

type TypographySizeVariants = typeof fontSizes[number];

type TypographylineHeightVariants = typeof lineHeights[number];

type Typography = { name: string; size: number; lineHeight: number };

interface Props extends HTMLAttributes<HTMLDivElement> {
  children?: ReactNode;
  text?: string;
  type?: TypographytypeVariants;
  size?: TypographySizeVariants;
  lineHeight?: TypographylineHeightVariants;
  extraClasses?: string;
}

export const Typography: FC<Props> = ({
  type = 'p',
  children = '',
  text,
  size,
  lineHeight,
  extraClasses,
  ...props
}) => {
  let component = type;

  const selectedTypography = typographies.find(
    (el: Typography) => el.name == type
  );
  const selectedSize =
    selectedTypography?.solid && selectedTypography
      ? selectedTypography.size
      : size || 14;
  const selectedLineHeight =
    selectedTypography?.solid && selectedTypography
      ? selectedTypography.lineHeight
      : lineHeight || 20;

  switch (type) {
    case 'title1':
    case 'title2':
    case 'title3':
    case 'title4':
    case 'title5':
      component = 'h2';
      break;

    case 'body1':
    case 'body2':
    case 'body3':
    case 'body4':
    case 'body5':
    case 'body6':
      component = 'p';
      break;

    case 'overline1':
    case 'overline2':
    case 'overline3':
      component = 'span';
      break;

    default:
      component = type;
      break;
  }

  return createElement(
    component,
    {
      ...props,
      className: `text-t1 text-${selectedSize} leading-${selectedLineHeight} ${extraClasses}`,
    },
    text || children
  );
};
