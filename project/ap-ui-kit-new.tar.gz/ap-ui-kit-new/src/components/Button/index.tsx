//ToDo: handle color property
//ToDo: check icon property
import React, { FC, HTMLAttributes, ReactNode } from 'react';
import {Ellipsis} from '../Ellipsis';

export interface ButtonProps extends HTMLAttributes<HTMLButtonElement> {
  text: string;
  loading?: boolean;
  disabled?: boolean;
  isReverse?: boolean;
  rightIcon?: ReactNode;
  leftIcon?: ReactNode;
  action?: Function;
  extraClasses?: string;
  size?: TButtonSizes;
}

export const Button: FC<ButtonProps> = ({
  text,
  rightIcon,
  leftIcon,
  action = () => {},
  loading = false,
  disabled = false,
  isReverse = false,
  extraClasses = '',
  size = 'medium',
  ...props
}) => {
  return (
    <button
      style={props.style}
      className={`rounded-12 w-full flex items-center justify-around relative ${
        disabled
          ? 'bg-gray-100 text-gray-400'
          : isReverse
          ? `text-red_dark border-solid border border-red_dark`
          : `bg-red_dark text-white-100`
      } ${extraClasses} ${
        size == 'large' ? 'h-56' : size == 'small' ? 'h-40' : 'h-48'
      } text-16 leading-22`}
      onClick={() => action()}
      disabled={loading || disabled}
      aria-label={text}
    >
      {loading ? (
        <Ellipsis />
      ) : (
        <>
          {rightIcon ? rightIcon : <></>}
          {text}
          {leftIcon ? leftIcon : <></>}
        </>
      )}
    </button>
  );
};
