import 'react-app-polyfill/ie11';
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { ThemeProvider } from '../.';

const App = () => {
  return (
      <ThemeProvider type="dark">
        <h1
          style={{
            color: 'var(--typographt-color-t1)',
            background: 'var(--card-color-background-color)',
          }}
        >
          Hello AP
        </h1>
      </ThemeProvider>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
